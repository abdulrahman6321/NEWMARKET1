namespace E_Commerce.Components {
    public class HeaderViewComponent : ViewComponent {
        public IViewComponentResult Invoke() {
            return View();
        }
    }
}