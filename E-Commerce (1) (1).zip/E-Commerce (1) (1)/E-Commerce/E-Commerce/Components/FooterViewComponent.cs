namespace E_Commerce.Components {
    public class FooterViewComponent : ViewComponent {
        public IViewComponentResult Invoke() {
            return View();
        }
    }
}